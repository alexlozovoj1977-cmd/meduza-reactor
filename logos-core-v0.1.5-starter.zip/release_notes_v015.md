# LOGOS-CORE v0.1.5: INЬ-FRC External Validation Package (0.15 Hz)

Внутрішній контур **PASS**. Готово до зовнішньої атестації (INЬ-FRC).
KPI: Stillpoint 0.15 Hz; P95 Snapshot 50.0 s (≤60 s); Entanglement 66 s (≤70 s);
Hyper-V Migration 12 s (≤15 s); Combined CASE-020 58 s (≤75 s).

**Repro Package:** INЬ-FRC.json, SBOM.cdx.json, CASE-ALL.zip, MANIFEST.json
**Verify > Trust:** звір SHA-256 у MANIFEST/SBOM.
